
var color=['#C71585','#8A2BE2','#8B008B','#FF1493','#228B22','#4B0082'];

var random=Math.floor(Math.random()*6);

var x=function(){
    
    $('.saved-category').css('backgroundColor',color[random]);
}
x();
 





